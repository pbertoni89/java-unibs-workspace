package objects;

public class Cannon extends ObjectImage {
	
	final static String iconPath = "objects\\cannon.png";  //TODO controllare che su linux non servano le slash inverse.
	
	public Cannon( int x, int y) {
		
		super(x,y,iconPath);
	}
	
}
